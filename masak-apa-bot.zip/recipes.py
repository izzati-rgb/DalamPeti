# recipes.py
# Edit this file to add, remove, or update recipes and substitutions.
# All recipes are for 2 servings, halal (no pork, no alcohol).

RECIPES = {
    "nasi_goreng_kampung": {
        "name": "Nasi Goreng Kampung",
        "time": "25 min",
        "why": "A classic fried rice that uses simple pantry staples.",
        "ingredients": [
            "cooked cold rice (2 cups)",
            "eggs (2)",
            "shallots or onion",
            "garlic",
            "bird's eye chillies or chilli paste",
            "belacan (optional)",
            "ikan bilis (optional)",
            "kangkung or other greens",
            "soy sauce",
        ],
        "key_ingredients": ["rice", "egg", "shallot", "bawang", "garlic", "bawang putih", "cili", "chilli", "kangkung"],
        "needed_extras": ["soy sauce", "shallots or onion", "garlic", "chillies or chilli paste"],
        "overview": (
            "1. Fry ikan bilis until crisp, set aside.\n"
            "2. Blend shallots, garlic, chillies and belacan into a paste.\n"
            "3. Fry the paste, then scramble the eggs in the same wok.\n"
            "4. Add rice, soy sauce, greens and toss together.\n"
            "5. Top with ikan bilis and serve hot."
        ),
        "steps": (
            "1. Heat 1 tbsp oil on medium-high. Fry ikan bilis until golden and crisp (~2 min). Set aside.\n"
            "2. Pound or blend shallots, garlic, chillies and belacan into a paste.\n"
            "3. In the same wok, heat 2 tbsp oil on medium-high. Fry paste for 2 min until fragrant.\n"
            "4. Push paste to the side. Crack in eggs and scramble until just set (~1 min).\n"
            "5. Add rice. Break up any clumps and stir-fry for 2 min.\n"
            "6. Add soy sauce and salt to taste. Add greens and toss for 1-2 min on high heat.\n"
            "7. Plate up and top with crispy ikan bilis. Serve immediately. 🍳"
        ),
        "tips": (
            "Tip 1: Day-old cold rice is best — freshly cooked rice makes it mushy.\n"
            "Tip 2: Keep the heat high when frying rice so it fries, not steams."
        ),
        "safety": "Make sure eggs are fully cooked with no runny white.",
    },
    "sambal_telur": {
        "name": "Sambal Telur",
        "time": "30 min",
        "why": "A rich, spicy egg dish that only needs eggs and a handful of aromatics.",
        "ingredients": [
            "eggs (4)",
            "shallots",
            "garlic",
            "dried chillies or chilli paste",
            "tomato",
            "tamarind juice or lime",
            "sugar",
        ],
        "key_ingredients": ["egg", "telur", "shallot", "bawang", "garlic", "bawang putih", "cili", "chilli", "tomato", "tomato"],
        "needed_extras": ["shallots", "garlic", "chillies or chilli paste", "tomato", "tamarind juice or lime"],
        "overview": (
            "1. Hard-boil eggs for 10 min, peel.\n"
            "2. Blend shallots, garlic and chillies into a sambal paste.\n"
            "3. Fry paste until fragrant and oil separates.\n"
            "4. Add tomato, tamarind, sugar and water — simmer.\n"
            "5. Add eggs, coat in sambal and serve with rice."
        ),
        "steps": (
            "1. Boil eggs in water on high heat for 10 min. Cool in cold water, then peel.\n"
            "2. Blend shallots, garlic and chillies (soaked dried chillies or chilli paste) into a smooth paste.\n"
            "3. Heat 3 tbsp oil on medium. Fry paste for 5-7 min, stirring often, until fragrant and oil separates at the edges.\n"
            "4. Add chopped tomato, 1 tbsp tamarind juice (or lime juice), 1 tsp sugar, a pinch of salt and 1/4 cup water.\n"
            "5. Simmer on low-medium for 3-5 min until sauce thickens.\n"
            "6. Add whole boiled eggs. Stir gently to coat for 2-3 min.\n"
            "7. Taste and adjust salt or sugar. Serve with rice. 🌶️"
        ),
        "tips": (
            "Tip 1: Fry the paste long enough — raw paste tastes bitter.\n"
            "Tip 2: For less heat, reduce the chillies and add more tomato."
        ),
        "safety": "Boil eggs fully — no runny yolk for this dish.",
    },
    "ayam_masak_kicap": {
        "name": "Ayam Masak Kicap",
        "time": "35 min",
        "why": "Tender chicken braised in sweet soy sauce — simple and satisfying.",
        "ingredients": [
            "chicken pieces (400 g)",
            "kicap manis (sweet soy sauce)",
            "soy sauce",
            "onion",
            "garlic",
            "ginger",
            "tomato (optional)",
        ],
        "key_ingredients": ["chicken", "ayam", "kicap", "soy sauce", "onion", "bawang", "garlic", "bawang putih", "ginger", "halia"],
        "needed_extras": ["kicap manis", "soy sauce", "onion", "garlic", "ginger"],
        "overview": (
            "1. Fry garlic, ginger and onion until soft.\n"
            "2. Brown the chicken pieces.\n"
            "3. Add kicap manis, soy sauce and water.\n"
            "4. Simmer covered 15-20 min until chicken is cooked and sauce thickens.\n"
            "5. Add tomato in the last 3 min."
        ),
        "steps": (
            "1. Heat 2 tbsp oil on medium. Fry sliced garlic, ginger and onion for 2-3 min until soft and fragrant.\n"
            "2. Add chicken pieces. Brown on all sides for about 5 min on medium-high heat.\n"
            "3. Add 3 tbsp kicap manis, 1 tbsp soy sauce, a pinch of pepper and 1/2 cup water. Stir to mix.\n"
            "4. Cover and simmer on low-medium for 15-20 min. Stir every 5 min.\n"
            "   Check that chicken is cooked: no pink inside, juices run clear.\n"
            "5. Add chopped tomato in the last 3 min. Let sauce reduce until thick and glossy.\n"
            "6. Taste and add salt if needed. Serve with rice. 🍗"
        ),
        "tips": (
            "Tip 1: Don't skip the browning step — it adds colour and flavour.\n"
            "Tip 2: If sauce gets too thick, add a splash of water."
        ),
        "safety": "Chicken must be fully cooked — no pink meat, juices run clear.",
    },
    "tumis_kangkung_belacan": {
        "name": "Tumis Kangkung Belacan",
        "time": "10 min",
        "why": "A quick stir-fry that lets fresh kangkung shine with just a little paste.",
        "ingredients": [
            "kangkung (1 bunch, ~250 g)",
            "garlic",
            "chillies",
            "belacan",
        ],
        "key_ingredients": ["kangkung", "water spinach", "garlic", "bawang putih", "cili", "chilli", "belacan"],
        "needed_extras": ["garlic", "chillies", "belacan"],
        "overview": (
            "1. Cut kangkung, keeping stems and leaves separate.\n"
            "2. Pound garlic, chillies and belacan.\n"
            "3. Fry paste on high heat for 1 min.\n"
            "4. Add stems first, then leaves, toss quickly.\n"
            "5. Season with salt and serve right away."
        ),
        "steps": (
            "1. Wash kangkung. Cut into 5 cm pieces. Keep stems and leaves in separate piles.\n"
            "2. Pound or blend garlic, chillies and belacan into a rough paste.\n"
            "3. Heat 1 tbsp oil on HIGH heat until smoking hot.\n"
            "4. Add paste and fry for 1 min, stirring fast.\n"
            "5. Add stems first. Toss for 1 min.\n"
            "6. Add leaves. Toss for 1-2 min — just until wilted.\n"
            "7. Add a pinch of salt if needed. Serve immediately. 🥬"
        ),
        "tips": (
            "Tip 1: High heat is key — it gives the smoky 'wok hei' flavour.\n"
            "Tip 2: Don't overcook. Soft, soggy kangkung means the heat was too low or it cooked too long."
        ),
        "safety": None,
    },
    "telur_dadar": {
        "name": "Telur Dadar Bawang",
        "time": "10 min",
        "why": "A simple Malaysian omelette with onion — ready in minutes.",
        "ingredients": [
            "eggs (3)",
            "onion (half, thinly sliced)",
            "chilli (optional)",
        ],
        "key_ingredients": ["egg", "telur", "onion", "bawang", "cili", "chilli"],
        "needed_extras": [],
        "overview": (
            "1. Beat eggs with salt, pepper, onion and chilli.\n"
            "2. Heat oil on medium.\n"
            "3. Pour in egg mixture.\n"
            "4. Cook until underside is golden, then flip.\n"
            "5. Cook 1-2 min more and serve."
        ),
        "steps": (
            "1. Crack 3 eggs into a bowl. Add a pinch of salt and pepper.\n"
            "2. Add thinly sliced onion and sliced chilli (if using). Beat well.\n"
            "3. Heat 1 tbsp oil on medium heat.\n"
            "4. Pour in the egg mixture. Cook for about 2 min until the underside is golden and mostly set.\n"
            "5. Carefully flip. Cook for 1-2 min more until fully set.\n"
            "6. Slide onto a plate and serve with rice."
        ),
        "tips": (
            "Tip 1: Use medium heat — too hot and the outside burns before the inside sets.\n"
            "Tip 2: Add a splash of water to the egg mix for a fluffier omelette."
        ),
        "safety": "Make sure the egg is fully cooked — no runny parts.",
    },
}

SUBSTITUTIONS = {
    "shallot": {
        "original": "shallot / bawang merah",
        "subs": [
            {"sub": "regular onion (half the amount)", "taste_change": "milder, less fragrant"},
        ],
    },
    "bawang merah": {
        "original": "shallot / bawang merah",
        "subs": [
            {"sub": "regular onion (half the amount)", "taste_change": "milder, less fragrant"},
        ],
    },
    "chilli": {
        "original": "fresh chilli / cili",
        "subs": [
            {"sub": "chilli powder or chilli paste (start with 1 tsp)", "taste_change": "similar heat, slightly different flavour"},
            {"sub": "dried chillies (soak in hot water 10 min first)", "taste_change": "deeper, smokier heat"},
        ],
    },
    "cili": {
        "original": "fresh chilli / cili",
        "subs": [
            {"sub": "chilli powder or chilli paste (start with 1 tsp)", "taste_change": "similar heat, slightly different flavour"},
            {"sub": "dried chillies (soak in hot water 10 min first)", "taste_change": "deeper, smokier heat"},
        ],
    },
    "belacan": {
        "original": "belacan (shrimp paste)",
        "subs": [
            {"sub": "a small splash of fish sauce", "taste_change": "less depth, slightly fishier"},
            {"sub": "a few dried shrimp", "taste_change": "similar depth, chunkier texture"},
            {"sub": "leave it out", "taste_change": "less umami depth overall"},
        ],
        "allergy_note": "Belacan contains shrimp.",
    },
    "kicap manis": {
        "original": "kicap manis (sweet soy sauce)",
        "subs": [
            {"sub": "1 tbsp soy sauce + 1 tsp sugar (per 1 tbsp kicap manis needed)", "taste_change": "less thick; simmer a little longer to thicken"},
        ],
    },
    "kicap": {
        "original": "kicap manis (sweet soy sauce)",
        "subs": [
            {"sub": "1 tbsp soy sauce + 1 tsp sugar (per 1 tbsp kicap manis needed)", "taste_change": "less thick; simmer a little longer to thicken"},
        ],
    },
    "tamarind": {
        "original": "tamarind juice / asam jawa",
        "subs": [
            {"sub": "lime juice (use slightly less)", "taste_change": "brighter, less earthy sourness"},
            {"sub": "extra tomato + a squeeze of lime", "taste_change": "milder sourness"},
        ],
    },
    "asam": {
        "original": "tamarind juice / asam jawa",
        "subs": [
            {"sub": "lime juice (use slightly less)", "taste_change": "brighter, less earthy sourness"},
            {"sub": "extra tomato + a squeeze of lime", "taste_change": "milder sourness"},
        ],
    },
    "ikan bilis": {
        "original": "ikan bilis (dried anchovies)",
        "subs": [
            {"sub": "dried shrimp (same amount)", "taste_change": "similar salty umami"},
            {"sub": "leave it out + a pinch more salt", "taste_change": "less crunch and umami"},
        ],
        "allergy_note": "Ikan bilis is fish.",
    },
    "kangkung": {
        "original": "kangkung (water spinach)",
        "subs": [
            {"sub": "bayam (spinach) — same amount", "taste_change": "softer texture, slightly milder"},
            {"sub": "sawi (mustard greens) — same amount", "taste_change": "slightly more bitter"},
            {"sub": "long beans — cut into 3 cm pieces, cook a little longer", "taste_change": "crunchier texture"},
        ],
    },
    "rice": {
        "original": "cold cooked rice",
        "subs": [
            {"sub": "cook fresh rice, spread on a tray and let cool for 30 min", "taste_change": "works well if spread thin and cooled"},
        ],
    },
    "nasi": {
        "original": "cold cooked rice",
        "subs": [
            {"sub": "cook fresh rice, spread on a tray and let cool for 30 min", "taste_change": "works well if spread thin and cooled"},
        ],
    },
    "chicken": {
        "original": "chicken / ayam",
        "subs": [
            {"sub": "firm tofu — pan-fry first until golden, shorter braising time (~10 min)", "taste_change": "lighter, absorbs sauce well"},
            {"sub": "tempeh — cut into cubes, shorter cooking time", "taste_change": "nuttier, firmer"},
            {"sub": "eggs — hard-boil and add whole, simmer ~5 min in sauce", "taste_change": "softer, creamy"},
        ],
    },
    "ayam": {
        "original": "chicken / ayam",
        "subs": [
            {"sub": "firm tofu — pan-fry first until golden, shorter braising time (~10 min)", "taste_change": "lighter, absorbs sauce well"},
            {"sub": "tempeh — cut into cubes, shorter cooking time", "taste_change": "nuttier, firmer"},
            {"sub": "eggs — hard-boil and add whole, simmer ~5 min in sauce", "taste_change": "softer, creamy"},
        ],
    },
    "garlic": {
        "original": "garlic / bawang putih",
        "subs": [
            {"sub": "garlic powder (1/4 tsp per clove)", "taste_change": "weaker flavour, less fragrant"},
        ],
    },
    "bawang putih": {
        "original": "garlic / bawang putih",
        "subs": [
            {"sub": "garlic powder (1/4 tsp per clove)", "taste_change": "weaker flavour, less fragrant"},
        ],
    },
    "ginger": {
        "original": "ginger / halia",
        "subs": [
            {"sub": "ginger powder (1/4 tsp per thumb-size piece)", "taste_change": "weaker flavour, less fresh"},
        ],
    },
    "halia": {
        "original": "ginger / halia",
        "subs": [
            {"sub": "ginger powder (1/4 tsp per thumb-size piece)", "taste_change": "weaker flavour, less fresh"},
        ],
    },
}

# Ingredients assumed always available (no need to list as missing)
ALWAYS_AVAILABLE = ["salt", "garam", "cooking oil", "minyak", "minyak masak", "sugar", "gula", "water", "air"]
