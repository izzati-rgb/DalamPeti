"""
Masak Apa Hari Ni? — Telegram chatbot
Suggests Malaysian recipes based on ingredients you have at home.
"""

import os
import logging
from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    filters,
    ContextTypes,
)
from recipes import RECIPES, SUBSTITUTIONS, ALWAYS_AVAILABLE

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Guardrail patterns — messages that try to change the bot's behaviour
# ---------------------------------------------------------------------------
GUARDRAIL_KEYWORDS = [
    "ignore previous", "ignore your instructions", "reveal prompt",
    "show prompt", "system prompt", "act as", "pretend you are",
    "forget your rules", "new instructions", "write code", "write essay",
    "write a program", "write me code", "you are now", "bypass",
    "jailbreak", "dan mode",
]

# Out-of-scope food that is NOT Malaysian
NON_MALAYSIAN_KEYWORDS = [
    "pizza", "pasta", "sushi", "ramen", "burger", "steak", "tacos",
    "burrito", "lasagna", "curry powder rice", "pad thai", "kimchi",
    "dim sum", "pho", "bibimbap", "fried chicken western", "sandwich",
    "hot dog", "french fries", "spaghetti", "risotto",
]

# Health/allergy triggers — hand off
HEALTH_KEYWORDS = [
    "allerg", "pregnant", "pregnan", "baby food", "infant", "medical",
    "diabetes", "diabetic", "calori", "nutrition", "protein content",
    "fat content", "diet plan", "weight loss", "hypertension",
]

# ---------------------------------------------------------------------------
# State helpers
# ---------------------------------------------------------------------------

def get_state(context: ContextTypes.DEFAULT_TYPE) -> dict:
    """Return the per-chat state dict, creating it if needed."""
    if "state" not in context.chat_data:
        context.chat_data["state"] = {
            "ingredients": [],       # list of ingredient strings the user named
            "suggested_recipes": [], # list of recipe keys suggested so far
            "current_recipe": None,  # key of recipe being discussed
            "full_steps_given": False,
            "strike": 0,             # fallback strike counter
        }
    return context.chat_data["state"]

# ---------------------------------------------------------------------------
# Recipe matching
# ---------------------------------------------------------------------------

def normalise(text: str) -> str:
    return text.lower().strip()


def score_recipe(recipe_key: str, user_ingredients: list[str]) -> int:
    """
    Count how many key_ingredients of the recipe appear in user_ingredients.
    Returns an integer score.
    """
    recipe = RECIPES[recipe_key]
    user_norm = [normalise(i) for i in user_ingredients]
    score = 0
    for key in recipe["key_ingredients"]:
        for ui in user_norm:
            if normalise(key) in ui or ui in normalise(key):
                score += 1
                break
    return score


def rank_recipes(user_ingredients: list[str]) -> list[str]:
    """Return recipe keys sorted by match score (descending)."""
    scored = [
        (key, score_recipe(key, user_ingredients))
        for key in RECIPES
    ]
    scored.sort(key=lambda x: x[1], reverse=True)
    return [key for key, _ in scored]


def find_missing(recipe_key: str, user_ingredients: list[str]) -> list[str]:
    """Return ingredients the user is missing for a recipe."""
    recipe = RECIPES[recipe_key]
    user_norm = [normalise(i) for i in user_ingredients]
    always_norm = [normalise(a) for a in ALWAYS_AVAILABLE]
    missing = []
    for ing in recipe["ingredients"]:
        ing_norm = normalise(ing)
        found = False
        # Check user ingredients
        for ui in user_norm:
            if ui in ing_norm or ing_norm in ui:
                found = True
                break
        # Check always-available
        if not found:
            for av in always_norm:
                if av in ing_norm or ing_norm in av:
                    found = True
                    break
        if not found:
            # Drop quantity text in brackets / parentheses for display
            clean = ing.split("(")[0].strip()
            missing.append(clean)
    return missing


# ---------------------------------------------------------------------------
# Intent detection
# ---------------------------------------------------------------------------

def detect_intent(text: str, state: dict) -> str:
    """Simple keyword-based intent classifier."""
    t = text.lower()

    # Guardrail check first
    for kw in GUARDRAIL_KEYWORDS:
        if kw in t:
            return "guardrail"

    # Health / allergy
    for kw in HEALTH_KEYWORDS:
        if kw in t:
            return "health"

    # Another recipe
    another_words = ["lain", "another", "other recipe", "different dish", "another dish",
                     "nak lain", "ada lagi", "lain tak", "other dish", "try something else",
                     "something else", "nak cuba lain"]
    for kw in another_words:
        if kw in t:
            return "another_recipe"

    # Substitute
    sub_words = ["takde", "tak ada", "don't have", "do not have", "ganti", "substitute",
                 "replace", "no ", "xde", "kurang", "not enough", "short of", "swap",
                 "without", "tanpa", "tiada"]
    for kw in sub_words:
        if kw in t:
            return "ask_substitute"

    # How to cook
    cook_words = ["macam mana nak masak", "how to cook", "how do i", "full steps",
                  "step by step", "cara masak", "boleh ajar", "teach me", "yes", "ya",
                  "ok", "okay", "nak masak", "start", "proceed", "go ahead", "sure",
                  "mahu", "mau", "nak", "boleh", "yes please", "yep", "yup",
                  "full recipe", "full guide"]
    for kw in cook_words:
        if kw in t:
            return "ask_how_to_cook"

    # Greeting
    greet_words = ["hello", "hi", "hai", "hey", "assalamualaikum", "salam", "helo", "start"]
    for kw in greet_words:
        if kw in t:
            return "greeting"

    # Ingredient list — look for food words or "I have" patterns
    have_words = ["i have", "ada", "ade", "saya ada", "aku ada", "got", "bahan",
                  "ingredients", "dalam fridge", "dalam peti", "kat rumah",
                  "at home", "fridge", "dapur"]
    for kw in have_words:
        if kw in t:
            return "give_ingredients"

    # If the message looks like a list of food items, treat as ingredients
    ingredient_hints = [
        "rice", "nasi", "egg", "telur", "chicken", "ayam", "kangkung",
        "garlic", "bawang", "onion", "chilli", "cili", "tomato", "tofu",
        "tahu", "tempe", "ikan", "udang", "belacan", "kicap", "ginger",
        "halia", "santan", "carrot", "lobak", "potato", "kentang",
        "cabbage", "kobis", "spinach", "bayam", "sawi",
    ]
    for kw in ingredient_hints:
        if kw in t:
            return "give_ingredients"

    return "unknown"


# ---------------------------------------------------------------------------
# Reply builders
# ---------------------------------------------------------------------------

def build_greeting() -> str:
    return (
        "Hai! 👋 Saya Masak Apa Hari Ni?\n\n"
        "I help you decide what Malaysian dish to cook\n"
        "using ingredients you already have at home.\n\n"
        "So, what ingredients do you have? 🍳\n"
        "(Example: rice, eggs, onion, garlic, chilli)"
    )


def build_recipe_suggestion(recipe_key: str, user_ingredients: list[str], others: list[str]) -> str:
    r = RECIPES[recipe_key]
    have = [i for i in user_ingredients if i]
    missing = find_missing(recipe_key, user_ingredients)

    lines = [
        f"I suggest: {r['name']} ({r['time']})",
        f"{r['why']}",
        "",
        f"You have: {', '.join(have) if have else '(not sure — check below)'}",
        f"You still need: {', '.join(missing) if missing else 'nothing extra! You have it all.'}",
        f"(salt, oil, sugar and water assumed available)",
        "",
        "Quick overview:",
        r["overview"],
    ]
    if others:
        other_names = [RECIPES[k]["name"] for k in others]
        lines += ["", f"Other options with your ingredients: {', '.join(other_names)}"]
    lines += ["", "Want the full step-by-step?"]
    return "\n".join(lines)


def build_full_steps(recipe_key: str) -> str:
    r = RECIPES[recipe_key]
    lines = [
        f"{r['name']} — full recipe (2 servings)",
        f"Time: {r['time']}",
        "",
        r["steps"],
        "",
        r["tips"],
    ]
    if r.get("safety"):
        lines += ["", f"⚠️  {r['safety']}"]
    lines += ["", "Missing or short of anything? Tell me and I'll suggest a swap."]
    return "\n".join(lines)


def build_substitute(ingredient_raw: str, recipe_key: str | None) -> str:
    """Find substitutes for the named ingredient."""
    ing_norm = normalise(ingredient_raw)

    # Try to find in substitutions dict
    matched_key = None
    for key in SUBSTITUTIONS:
        if key in ing_norm or ing_norm in key:
            matched_key = key
            break

    if matched_key is None:
        # Try partial word match
        for key in SUBSTITUTIONS:
            if any(word in ing_norm for word in key.split()):
                matched_key = key
                break

    if matched_key is None:
        return (
            f"Hmm, I don't have a specific substitute for '{ingredient_raw}' in my list.\n"
            "You can try leaving it out, or use a similar ingredient you have.\n"
            "If it's a main ingredient, a smaller portion usually works too."
        )

    sub_data = SUBSTITUTIONS[matched_key]
    lines = [f"No {sub_data['original']}? Here are some swaps:"]
    for i, s in enumerate(sub_data["subs"], 1):
        lines.append(f"{i}. {s['sub']}")
        lines.append(f"   Taste change: {s['taste_change']}")
    if sub_data.get("allergy_note"):
        lines += ["", f"Note: {sub_data['allergy_note']}"]

    lines += ["", "Also: if you just don't have enough,"]
    lines += ["try making a smaller portion, or stretch it with"]
    lines += ["sliced vegetables, tofu or an extra egg."]

    if recipe_key:
        r = RECIPES[recipe_key]
        lines += ["", f"Here are the full steps again for {r['name']}:", "", r["steps"], "", r["tips"]]
        if r.get("safety"):
            lines += ["", f"⚠️  {r['safety']}"]

    return "\n".join(lines)


def build_fallback_strike1(lang_hint: str) -> str:
    if lang_hint == "ms":
        return "Maaf, saya kurang faham. Boleh cuba tanya cara lain?"
    return "Sorry, I'm not sure I understood. Could you try asking another way?"


def build_fallback_strike2(lang_hint: str) -> str:
    if lang_hint == "ms":
        return (
            "Saya masih kurang faham. Nak cuba salah satu daripada ini?\n\n"
            "1. Beritahu saya bahan-bahan yang ada\n"
            "2. Cara masak resepi yang dipilih\n"
            "3. Ganti bahan yang tiada"
        )
    return (
        "I still don't quite understand. Would you like to:\n\n"
        "1. Tell me your ingredients\n"
        "2. Get cooking steps for a recipe\n"
        "3. Find a substitute for an ingredient"
    )


def build_fallback_final(lang_hint: str) -> str:
    if lang_hint == "ms":
        return (
            "Maaf, saya tak dapat bantu dengan soalan ini.\n"
            "Cuba tanya ahli keluarga, tengok buku masakan,\n"
            "atau laman web resepi yang dipercayai."
        )
    return (
        "I can't help with this one.\n"
        "Try asking family, a cookbook or a trusted recipe website."
    )


def detect_language(text: str) -> str:
    """Very rough Malay / English detector. Returns 'ms' or 'en'."""
    malay_words = ["saya", "aku", "ada", "nak", "boleh", "macam mana",
                   "bahan", "masak", "tak", "tiada", "lah", "leh", "eh",
                   "la", "kan", "mau", "mahu", "resepi", "dapur"]
    t = text.lower()
    for w in malay_words:
        if w in t:
            return "ms"
    return "en"


def extract_ingredient_from_sub_request(text: str) -> str | None:
    """Try to pull out the ingredient the user mentioned in a substitute request."""
    t = text.lower()

    # Common patterns: "no X", "tak ada X", "without X", "no more X", "ganti X", "I don't have X"
    import re
    patterns = [
        r"no more (\w[\w\s]*)",
        r"no (\w[\w\s]*)",
        r"don[''`]?t have (\w[\w\s]*)",
        r"do not have (\w[\w\s]*)",
        r"without (\w[\w\s]*)",
        r"tak ada (\w[\w\s]*)",
        r"takde (\w[\w\s]*)",
        r"tiada (\w[\w\s]*)",
        r"ganti (\w[\w\s]*)",
        r"substitute for (\w[\w\s]*)",
        r"replace (\w[\w\s]*)",
        r"swap (\w[\w\s]*)",
        r"short of (\w[\w\s]*)",
        r"kurang (\w[\w\s]*)",
        r"xde (\w[\w\s]*)",
    ]
    for pat in patterns:
        m = re.search(pat, t)
        if m:
            candidate = m.group(1).strip()
            # Remove trailing filler words
            for stop in ["lah", "la", "je", "only", "here", "at home", "in fridge"]:
                candidate = candidate.replace(stop, "").strip()
            if candidate:
                return candidate
    return None


# ---------------------------------------------------------------------------
# Telegram handlers
# ---------------------------------------------------------------------------

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    state = get_state(context)
    # Reset state on /start
    state.update({
        "ingredients": [],
        "suggested_recipes": [],
        "current_recipe": None,
        "full_steps_given": False,
        "strike": 0,
    })
    await update.message.reply_text(build_greeting())


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text or ""
    state = get_state(context)
    lang = detect_language(text)
    intent = detect_intent(text, state)

    # -----------------------------------------------------------------------
    # Guardrail
    # -----------------------------------------------------------------------
    if intent == "guardrail":
        await update.message.reply_text(
            "I can only help with Malaysian recipes from your ingredients."
        )
        return

    # -----------------------------------------------------------------------
    # Health / allergy hand-off
    # -----------------------------------------------------------------------
    if intent == "health":
        await update.message.reply_text(
            "I can't give advice on allergies, medical diets or health topics.\n"
            "Please ask a doctor or dietitian — they'll give you proper guidance."
        )
        return

    # -----------------------------------------------------------------------
    # Non-Malaysian food check
    # -----------------------------------------------------------------------
    t_lower = text.lower()
    for kw in NON_MALAYSIAN_KEYWORDS:
        if kw in t_lower:
            await update.message.reply_text(
                f"I only know Malaysian recipes, sorry!\n\n"
                f"The closest Malaysian dish I can suggest depends on\n"
                f"what ingredients you have at home.\n\n"
                f"What ingredients do you have?"
            )
            state["strike"] = 0
            return

    # -----------------------------------------------------------------------
    # Greeting
    # -----------------------------------------------------------------------
    if intent == "greeting":
        state["strike"] = 0
        await update.message.reply_text(build_greeting())
        return

    # -----------------------------------------------------------------------
    # Give ingredients
    # -----------------------------------------------------------------------
    if intent == "give_ingredients":
        # Extract ingredient list from the message
        ingredients = parse_ingredients(text)
        state["ingredients"] = ingredients
        state["suggested_recipes"] = []
        state["current_recipe"] = None
        state["full_steps_given"] = False
        state["strike"] = 0

        ranked = rank_recipes(ingredients)
        if not ranked:
            await update.message.reply_text(
                "Hmm, I couldn't match any recipe to those ingredients.\n"
                "Could you list them again? (e.g. rice, eggs, garlic, onion)"
            )
            return

        best = ranked[0]
        others = [r for r in ranked[1:3] if score_recipe(r, ingredients) > 0]
        state["current_recipe"] = best
        state["suggested_recipes"] = [best] + others

        await update.message.reply_text(
            build_recipe_suggestion(best, ingredients, others)
        )
        return

    # -----------------------------------------------------------------------
    # Ask how to cook
    # -----------------------------------------------------------------------
    if intent == "ask_how_to_cook":
        state["strike"] = 0
        recipe_key = state.get("current_recipe")

        if not recipe_key:
            # No recipe chosen yet
            if state.get("ingredients"):
                ranked = rank_recipes(state["ingredients"])
                recipe_key = ranked[0]
                state["current_recipe"] = recipe_key
            else:
                await update.message.reply_text(
                    "Which dish would you like to cook?\n"
                    "Or tell me your ingredients and I'll suggest one."
                )
                return

        state["full_steps_given"] = True
        await update.message.reply_text(build_full_steps(recipe_key))
        return

    # -----------------------------------------------------------------------
    # Ask substitute
    # -----------------------------------------------------------------------
    if intent == "ask_substitute":
        state["strike"] = 0
        ingredient = extract_ingredient_from_sub_request(text)

        if not ingredient:
            await update.message.reply_text(
                "Which ingredient are you missing or short of?\n"
                "(e.g. 'I don't have belacan' or 'tak ada kangkung')"
            )
            return

        recipe_key = state.get("current_recipe")
        await update.message.reply_text(
            build_substitute(ingredient, recipe_key)
        )
        return

    # -----------------------------------------------------------------------
    # Another recipe
    # -----------------------------------------------------------------------
    if intent == "another_recipe":
        state["strike"] = 0
        ingredients = state.get("ingredients", [])

        if not ingredients:
            await update.message.reply_text(
                "What ingredients do you have at home?\n"
                "Tell me and I'll suggest another dish."
            )
            return

        ranked = rank_recipes(ingredients)
        suggested = state.get("suggested_recipes", [])

        # Pick next recipe not yet suggested
        next_recipe = None
        for r in ranked:
            if r not in suggested and score_recipe(r, ingredients) > 0:
                next_recipe = r
                break

        if not next_recipe:
            # Wrap around — suggest all options again
            if ranked:
                next_recipe = ranked[0]
                state["suggested_recipes"] = []
            else:
                await update.message.reply_text(
                    "I don't have another recipe that fits your ingredients.\n"
                    "Try adding one or two more ingredients and I'll look again!"
                )
                return

        state["current_recipe"] = next_recipe
        state["suggested_recipes"] = suggested + [next_recipe]
        state["full_steps_given"] = False

        others = [r for r in ranked if r not in state["suggested_recipes"]][:2]
        await update.message.reply_text(
            build_recipe_suggestion(next_recipe, ingredients, others)
        )
        return

    # -----------------------------------------------------------------------
    # Out-of-scope / unknown — fallback with two-strike rule
    # -----------------------------------------------------------------------
    state["strike"] = state.get("strike", 0) + 1

    if state["strike"] == 1:
        await update.message.reply_text(build_fallback_strike1(lang))
    elif state["strike"] == 2:
        await update.message.reply_text(build_fallback_strike2(lang))
    else:
        state["strike"] = 0
        await update.message.reply_text(build_fallback_final(lang))


# ---------------------------------------------------------------------------
# Ingredient parser
# ---------------------------------------------------------------------------

def parse_ingredients(text: str) -> list[str]:
    """
    Extract a list of ingredient names from a free-text message.
    Splits on commas, 'and', newlines, and 'dan'.
    """
    import re
    # Remove common preamble phrases
    for phrase in [
        "i have", "saya ada", "aku ada", "ada", "bahan saya",
        "my ingredients are", "ingredients:", "bahan:", "at home i have",
        "dalam fridge ada", "kat rumah ada", "got", "i've got",
    ]:
        text = re.sub(phrase, ",", text, flags=re.IGNORECASE)

    # Split on commas, 'and', 'dan', newlines, semicolons
    parts = re.split(r"[,\n;]|\band\b|\bdan\b", text, flags=re.IGNORECASE)
    ingredients = []
    for part in parts:
        clean = part.strip(" .\t\r")
        # Remove leading numbers like "1." "2)"
        clean = re.sub(r"^\d+[\.\)]\s*", "", clean)
        if len(clean) >= 2:
            ingredients.append(clean)
    return ingredients


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    if not token:
        raise RuntimeError(
            "TELEGRAM_BOT_TOKEN environment variable is not set.\n"
            "Copy .env.example to .env and add your token."
        )

    app = ApplicationBuilder().token(token).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    logger.info("Bot is running. Press Ctrl+C to stop.")
    app.run_polling()


if __name__ == "__main__":
    main()
